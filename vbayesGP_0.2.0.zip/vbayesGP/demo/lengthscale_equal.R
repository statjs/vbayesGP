# Generate Data 1 (rmethod = equal)
dat1 <- bkmr::SimData(n = 200, M = 1, sigsq.true = 0.5, beta.true = 2, hfun = 1, Zgen = 'norm',
                      ind = 1, family = 'gaussian')

y <- dat1$y; n <- length(y)
Z <- dat1$Z; M <- ncol(Z)
X <- dat1$X; p <- ncol(X)
true.h <- dat1$h

# fit the BKMR
(bkmr.time <- system.time({
  fout.bkmr <- bkmr::kmbayes(y = y, Z = Z, X = X, iter = 10000, rmethod = 'equal', verbose = FALSE)
})[3])
summary(fout.bkmr)
bkmr.h <- bkmr::ComputePostmeanHnew(fout.bkmr)$postmean


# fit the vbayesGP meanfield
priors <- list(lengthscale='normal')
(mvb.time <- system.time({
  fout.diag <- vbayesGP::gvagpr(y, X, Z, priors = priors, covstr = 'diagonal')
})[3])
summary(fout.diag)
mvb.h <- fitted(fout.diag)$fmean


# fit the vbayesGP full rank
(fvb.time <- system.time({
  fout.full <- vbayesGP::gvagpr(y, X, Z, priors = priors, covstr = 'fullrank')
})[3])
summary(fout.full)
fvb.h <- fitted(fout.full)$fmean


#### Minibatch (uniform)
# fit the vbayesGP meanfield
control <- list(nbatch = 2)
(mvbmbu.time <- system.time({
  foutmbu.diag <- vbayesGP::gvagpr(y, X, Z, priors = priors, control = control, covstr = 'diagonal', minibatch = TRUE)
})[3])
summary(foutmbu.diag)
mvbmb.h <- fitted(foutmbu.diag)$fmean


# fit the vbayesGP full rank
(fvbmbu.time <- system.time({
  foutmbu.full <- vbayesGP::gvagpr(y, X, Z, priors = priors, control = control, covstr = 'fullrank', minibatch = TRUE)
})[3])
summary(foutmbu.full)
fvbmb.h <- fitted(foutmbu.full)$fmean


