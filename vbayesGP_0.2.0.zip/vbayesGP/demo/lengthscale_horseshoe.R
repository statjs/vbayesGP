# Generate Data 3 (rmethod = varying & selection)
dat3 <- bkmr::SimData(n = 500, M = 5, sigsq.true = 0.5, beta.true = 2, hfun = 3, Zgen = 'norm',
                      ind = 1:2, family = 'gaussian')

y <- dat3$y
Z <- dat3$Z; M <- ncol(Z)
X <- dat3$X
true.h <- dat3$h

# fit the BKMR
(bkmr.time <- system.time({
  fout.bkmr <- bkmr::kmbayes(y = y, Z = Z, X = X, iter = 10000, rmethod = 'varying', varsel = TRUE, verbose = FALSE)
})[3])
summary(fout.bkmr)
bkmr.h <- bkmr::ComputePostmeanHnew(fout.bkmr)$postmean


# fit the vbayesGP meanfield
priors <- list(lengthscale='horseshoe', asig=0.001, bsig=0.001, alam=10, blam=1, lam0=1, tau0=1)
(mvb.time <- system.time({
  fout.diag <- vbayesGP::gvagpr(y, X, Z, priors = priors, covstr = 'diagonal')
})[3])
summary(fout.diag)
mvb.h <- fitted(fout.diag)$fmean


# fit the vbayesGP full rank
(fvb.time <- system.time({
  fout.full <- vbayesGP::gvagpr(y, X, Z, priors = priors, covstr = 'fullrank')
})[3])
summary(fout.full)
fvb.h <- fitted(fout.full)$fmean


#### Minibatch (uniform)
# fit the vbayesGP meanfield
control <- list(nbatch = 3)
(mvbmbu.time <- system.time({
  foutmbu.diag <- vbayesGP::gvagpr(y, X, Z, priors = priors, covstr = 'diagonal', control = control, minibatch = TRUE)
})[3])
summary(foutmbu.diag)
mvbmb.h <- fitted(foutmbu.diag)$fmean


# fit the vbayesGP full rank
(fvbmbu.time <- system.time({
  foutmbu.full <- vbayesGP::gvagpr(y, X, Z, priors = priors, covstr = 'fullrank', control = control, minibatch = TRUE)
})[3])
summary(foutmbu.full)
fvbmb.h <- fitted(foutmbu.full)$fmean


