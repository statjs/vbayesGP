# data generation
seed <- 111
set.seed(seed)
n <- 200        ## number of observations
M <- 4          ## number of exposure variables
beta.true <- 0.1
Z <- matrix(runif(n * M, -1, 1), n, M)
X <- as.matrix(3*cos(Z[, 1]) + 2*rnorm(n))

## exposure-response function
hfun0 <- function(z) (2*z + 0.5) ^ 2
hfun <- function(zvec) hfun0(zvec[1]) + hfun0(zvec[2]) - hfun0(zvec[3]) - hfun0(zvec[4]) + zvec[3]*zvec[4]
h <- apply(Z, 1, hfun) ## only depends on z1, z2, z3, z4

## generate responses
ystar <- X %*% beta.true + h
prob <- 1 / (1 + exp(-ystar))
y <- rbinom(n = n, size = 1, prob = prob)

# GVB logistic
priors <- list(lengthscale = 'horseshoe', alam = 0.001, blam = 0.001, lam0 = 5, tau0 = 5)
control <- list(max_iter = 100000, rho = 0.95, eps = 1e-6, nws = 10000, nsp = 5)

vbtime <- system.time({
  fitgva <- vbayesGP::gvaggpr(y, X, Z, family = binomial(link = 'logit'), priors = priors, control = control)
})[3]
plot(fitgva)
summary(fitgva)
vbayesGP::extractELBO(fitgva)
gva.h <- fitted(fitgva)$fmean
gva.Xb <- X %*% fitgva$mu[n+1]
gva.phat <- 1 / (1 + exp( - (gva.Xb + gva.h)))
mean( y == as.integer(gva.phat > 0.5))

# univariate
pred.resp.univar.gva <- vbayesGP::predictorResponseUnivar(fit = fitgva, center = FALSE)
plot(pred.resp.univar.gva)

# bivariate
pred.resp.bivar.gva <- vbayesGP::predictorResponseBivar(fit = fitgva, min.plot.dist = 1)
plot(pred.resp.bivar.gva)
