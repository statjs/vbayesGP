library(ggplot2)


# Generate Data3 (rmethod = varying & selection)
set.seed(1)
Hfun <- function(z, ind=1:2) 4 * plogis(1/4 * (z[,ind[1]] + z[,ind[2]] + 1/2 * z[,ind[1]] * z[,ind[2]]), 0, 0.3)
beta.true <- 2
sigmasq.true <- 0.5

n <- 1000; M <- 5
X <- matrix(rnorm(n), n, 1)
Z <- matrix(rnorm(n*M), n, M)
true.h <- Hfun(Z)
y <- X %*% beta.true + true.h + rnorm(n, sd = sqrt(sigmasq.true))


# fit the vbayesGP meanfield
priors <- list(lengthscale = 'horseshoe')
control <- list(nbatch = 3)
(mvbmbu.time <- system.time({
  foutmbu.diag <- vbayesGP::gvagpr(y, X, Z, priors = priors, covstr = 'diagonal', control = control, minibatch = TRUE)
})[3])

# univariate
pred.resp.univar.gva <- vbayesGP::predictorResponseUnivar(fit = foutmbu.diag, center = FALSE)
plot(pred.resp.univar.gva)

# bivariate
pred.resp.bivar.gva <- vbayesGP::predictorResponseBivar(fit = foutmbu.diag, min.plot.dist = 1)
plot(pred.resp.bivar.gva)



