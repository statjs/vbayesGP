# Generate Data 4 (rmethod = varying & variable selection) - Random Slope
Hfun3 <- function (z, ind = 1:2) {
  4 * plogis(1/4 * (z[,ind[1]] + z[,ind[2]] + 1/2 * z[,ind[1]] * z[,ind[2]]), 0, 0.3)
}

N <- 100; R <- 3
D <- N * R
M <- 5
p <- 1
q <- 2

beta.true <- 2
sigsq.true <- 0.5
SIGMAb.true <- matrix(c(0.5, 0.1, 0.1, 0.3), q, q)

set.seed(1)
b.true <- MASS::mvrnorm(n=N, mu = rep(0, q), Sigma = SIGMAb.true)
bvec <- as.vector(t(b.true))
ID <- rep(1:N,each=R)

Z <- matrix(rnorm(D * M), D, M);colnames(Z) <- paste0("z", 1:M)
X <- matrix(rnorm(D * p), D, p)
U <- matrix(0, D, N*q)
for (i in 1:N) {
  U[((i-1)*R+1):(i*R),((i-1)*q+1):(i*q)] <- cbind(1, X[((i-1)*R+1):(i*R)])
}

true.h <- Hfun3(Z)
y <- X %*% beta.true + true.h + U %*% bvec + rnorm(D, sd = sqrt(sigsq.true))


# fit the vbayesGP meanfield
priors <- list(lengthscale='horseshoe', asig=0.001, bsig=0.001, alam=10, blam=1, lam0=1, tau0=1, vtaub=100)
(mvb.time <- system.time({
  fout.diag <- vbayesGP::gvagpr(y, X, Z, id = ID, random.slope = 1, priors = priors, covstr = 'diagonal')
})[3])
summary(fout.diag)
mvb.h <- fitted(fout.diag)$fmean


# fit the vbayesGP full rank
(fvb.time <- system.time({
  fout.full <- vbayesGP::gvagpr(y, X, Z, id = ID, random.slope = 1, priors = priors, covstr = 'fullrank')
})[3])
summary(fout.full)
fvb.h <- fitted(fout.full)$fmean




