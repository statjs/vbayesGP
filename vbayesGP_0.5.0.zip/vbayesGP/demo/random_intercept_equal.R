# Generate Data 3 (rmethod = equal)
# Random Intercept
Hfun3 <- function (z, ind = 1:2) {
  4 * plogis(1/4 * (z[,ind[1]] + z[,ind[2]] + 1/2 * z[,ind[1]] * z[,ind[2]]), 0, 0.3)
}

N <- 100; R <- 3
D <- N * R
M <- 5
p <- 1
q <- 1

beta.true <- 2
sigsq.true <- 0.5

set.seed(1)
b.true <- rnorm(N, sd = 0.8)
ID <- rep(1:N,each=R)

U <- matrix(0, D, N*q)
for (i in 1:N) {
  U[((i-1)*R+1):(i*R),((i-1)*q+1):(i*q)] <- 1
}

Z <- matrix(rnorm(D * M), D, M);colnames(Z) <- paste0("z", 1:M)
X <- matrix(rnorm(D * p), D, p)
true.h <- Hfun3(Z)
y <- X %*% beta.true + true.h + U %*% b.true + rnorm(D, sd = sqrt(sigsq.true))


# fit the BKMR
(bkmr.time <- system.time({
  fout.bkmr <- bkmr::kmbayes(y = y, Z = Z, X = X, iter = 10000, id = ID, rmethod = 'equal', varsel = FALSE, verbose = FALSE)
})[3])
summary(fout.bkmr)


# fit the vbayesGP meanfield
priors <- list(lengthscale='normal', asig=0.001, bsig=0.001, alam=10, blam=1, tau0=10)
(mvb.time <- system.time({
  fout.diag <- vbayesGP::gvagpr(y, X, Z, id = ID, priors = priors, covstr = 'diagonal')
})[3])
summary(fout.diag)


# fit the vbayesGP full rank
(fvb.time <- system.time({
  fout.full <- vbayesGP::gvagpr(y, X, Z, id = ID, priors = priors, covstr = 'fullrank')
})[3])
summary(fout.full)


# fit the vbayesGP sparse precision matrix
(svb.time <- system.time({
  fout.sparse <- vbayesGP::gvagpr(y, X, Z, id = ID, priors = priors, covstr = 'sparseprec')
})[3])
summary(fout.sparse)



