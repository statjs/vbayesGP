# Generate Data 4 (rmethod = varying & variable selection) - Random Slope
Hfun3 <- function (z, ind = 1:2) {
  4 * plogis(1/4 * (z[,ind[1]] + z[,ind[2]] + 1/2 * z[,ind[1]] * z[,ind[2]]), 0, 0.3)
}

N <- 200; R <- 5
D <- N * R
M <- 13
p <- 1
q <- 2

print(paste0("N = ", N, ", R = ", R, sep = ''))

beta.true <- 2
sigsq.true <- 0.5
SIGMAb.true <- matrix(c(0.5, 0.1, 0.1, 0.3), q, q)

set.seed(1)
b.true <- MASS::mvrnorm(n=N, mu = rep(0, q), Sigma = SIGMAb.true)
bvec <- as.vector(t(b.true))
ID <- rep(1:N,each=R)

VarRealistic <- structure(c(0.72, 0.65, 0.45, 0.48, 0.08,
            0.14, 0.16, 0.42, 0.2, 0.11, 0.35, 0.1, 0.11, 0.65,
            0.78, 0.48, 0.55, 0.06, 0.09, 0.17, 0.2, 0.16, 0.11,
            0.32, 0.12, 0.12, 0.45, 0.48, 0.56, 0.43, 0.11, 0.15,
            0.23, 0.25, 0.28, 0.16, 0.31, 0.15, 0.14, 0.48, 0.55,
            0.43, 0.71, 0.2, 0.23, 0.32, 0.22, 0.29, 0.14, 0.3,
            0.22, 0.18, 0.08, 0.06, 0.11, 0.2, 0.95, 0.7, 0.45,
            0.22, 0.29, 0.16, 0.24, 0.2, 0.13, 0.14, 0.09, 0.15,
            0.23, 0.7, 0.8, 0.36, 0.3, 0.35, 0.13, 0.23, 0.17,
            0.1, 0.16, 0.17, 0.23, 0.32, 0.45, 0.36, 0.83, 0.24,
            0.37, 0.2, 0.36, 0.34, 0.25, 0.42, 0.2, 0.25, 0.22,
            0.22, 0.3, 0.24, 1.03, 0.41, 0.13, 0.39, 0.1, 0.1,
            0.2, 0.16, 0.28, 0.29, 0.29, 0.35, 0.37, 0.41, 0.65,
            0.18, 0.3, 0.18, 0.16, 0.11, 0.11, 0.16, 0.14, 0.16,
            0.13, 0.2, 0.13, 0.18, 0.6, 0.18, 0.13, 0.08, 0.35,
            0.32, 0.31, 0.3, 0.24, 0.23, 0.36, 0.39, 0.3, 0.18,
            0.79, 0.42, 0.12, 0.1, 0.12, 0.15, 0.22, 0.2, 0.17,
            0.34, 0.1, 0.18, 0.13, 0.42, 1.27, 0.1, 0.11, 0.12,
            0.14, 0.18, 0.13, 0.1, 0.25, 0.1, 0.16, 0.08, 0.12,
            0.1, 0.67), .Dim = c(13L, 13L))

Z <- MASS::mvrnorm(n = D, mu = rep(0, M), Sigma = VarRealistic);colnames(Z) <- paste0("z", 1:M)
X <- matrix(rnorm(D * p), D, p)
U <- matrix(0, D, N*q)
for (i in 1:N) {
  U[((i-1)*R+1):(i*R),((i-1)*q+1):(i*q)] <- cbind(1, X[((i-1)*R+1):(i*R)])
}

true.h <- Hfun3(Z)
y <- X %*% beta.true + true.h + U %*% bvec + rnorm(D, sd = sqrt(sigsq.true))


# fit the vbayesGP meanfield
priors <- list(lengthscale='horseshoe', asig=0.001, bsig=0.001, alam=10, blam=1, lam0=1, tau0=1, vtaub=100)
(mvb.time <- system.time({
  fout.diag <- vbayesGP::gvagpr(y, X, Z, id = ID, random.slope = 1, priors = priors, covstr = 'diagonal')
})[3])
summary(fout.diag)


# fit the vbayesGP full rank
(fvb.time <- system.time({
  fout.full <- vbayesGP::gvagpr(y, X, Z, id = ID, random.slope = 1, priors = priors, covstr = 'fullrank')
})[3])
summary(fout.full)



# fit the vbayesGP sparse precision matrix
(svb.time <- system.time({
  fout.sparse <- vbayesGP::gvagpr(y, X, Z, id = ID, random.slope = 1, priors = priors, covstr = 'sparseprec')
})[3])
summary(fout.sparse)

