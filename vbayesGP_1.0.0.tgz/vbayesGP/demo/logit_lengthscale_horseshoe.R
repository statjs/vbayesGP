# data generation
seed <- 111
set.seed(seed)
n <- 1000        ## number of observations
M <- 4           ## number of exposure variables
beta.true <- 0.1
Z <- matrix(runif(n * M, -1, 1), n, M)
X <- as.matrix(3*cos(Z[, 1]) + 2*rnorm(n))

## exposure-response function
hfun0 <- function(z) (2*z + 0.5) ^ 2
hfun <- function(zvec) hfun0(zvec[1]) #+ hfun0(zvec[2]) - hfun0(zvec[3]) - hfun0(zvec[4]) + zvec[3]*zvec[4]
h <- apply(Z, 1, hfun) ## only depends on z1, z2, z3, z4

## generate responses
ystar <- X %*% beta.true + h
prob <- 1 / (1 + exp(-ystar))
y <- rbinom(n = n, size = 1, prob = prob)

# GVB logistic
priors <- list(lengthscale = 'horseshoe', alam = 10, blam = 1, lam0 = 0.1, tau0 = 0.1)
# control <- list(max_iter = 100000, rho = 0.95, eps = 1e-6, nws = 2500, nsp = 100, ninpts = 100)
control <- list(max_iter = 100000, rho = 0.001, eps = 0.9, nws = 2500, nsp = 100, ninpts = 100)
minibatch <- list(sampling = TRUE, method = 'nearby', nbatch = 200)

vbtime <- system.time({
  fitgva <- vbayesGP::gvaggpr(y, X, Z, family = binomial(link = 'logit'), priors = priors, control = control, covstr = 'fullrank', minibatch = minibatch)
})[3]
plot(fitgva)
summary(fitgva)
# vbayesGP::extractELBO(fitgva)
# gva.h <- fitted(fitgva)$fmean
# plot(h ~ gva.h, pch = 20)
# abline(a = 0, b = 1, col = 'red', lwd = 3)
# gva.Xb <- X %*% fitgva$mu[1:ncol(X)]
# gva.phat <- 1 / (1 + exp( - (gva.Xb + gva.h)))
# mean( y == as.integer(gva.phat > 0.5))
