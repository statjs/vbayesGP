# vbayesGP 1.1.3

## New prior option names

* The continuous shrinkage prior on the inverse length-scale parameters is now
  selected by `priors = list(lengthscale = "betaprime")` in `gvaggpr()`, naming
  the prior that is actually used. `"shrinkage"` is still accepted as a
  deprecated alias, and models fitted with earlier versions are still handled by
  `summary()`, `print()`, `computePPIPs()`, `extractELBO()` and
  `extractPostSamps()`.

* In `gvagpmim()` the non-shrinkage option is now `"indep.normal"`, matching the
  other fitting functions. The index parameterization carries one component per
  exposure, so there is no isotropic option here; `"normal"` is accepted as a
  deprecated alias for `"indep.normal"`. In `gvagpr()` and `gvaggpr()`,
  `"normal"` continues to mean a single length-scale shared by all exposures and
  `"indep.normal"` one length-scale per exposure.

## Covariance structures

* `covstr` gains the value `"blockdiag"`. For a mixed effect model the parameter
  vector is partitioned by cluster and an unrestricted Cholesky factor is not
  offered, so `"fullrank"` has always produced a block-diagonal covariance
  matrix there; the structure now has a name of its own. An option that does not
  apply to the model at hand falls back to the closest one that does, with a
  warning: `"fullrank"` becomes `"blockdiag"` when random effects are present,
  and `"blockdiag"` and `"sparseprec"` become `"fullrank"` when they are not.
  The fitted object records the structure that was actually used.

## Bug fixes

* `gvaggpr()` no longer fails when `inits$mu` is not supplied. It now defaults to
  a vector of zeros of the required length, as the documentation stated, and a
  supplied vector of the wrong length is reported instead of being passed to the
  compiled code.

* `covstr = "sparseprec"` no longer fails for mixed effect models. The
  triplet indices of the sparse Cholesky factor were passed to a constructor
  that interprets its second argument as column pointers, so every fit stopped
  with an Armadillo error.

* `gvagpmim()` no longer fails when `Z` is supplied as a matrix together with
  `m.index`; the number of index groups was left undefined on that path.

* Fitting a mixed effect model with a single exposure, or with a single
  covariate in `gvaggpr()`, no longer fails: reordering the rows by cluster
  dropped the matrix to a vector.

* `gvagpmim()` accepts an index group containing a single exposure, so that
  grouped and individual exposures can be combined in one model. Selecting a
  single column dropped the group to a vector, in the fitting function and in
  `fitted()`, `predict()`, `summary()`, `computePPIPs()` and
  `extractPostSamps()`.

* `fitted()` and `predict()` return the correct exposure--response surface for
  the mixed effect models fitted by `gvaggpr()`. The inducing values and their
  block of the variational covariance matrix were read from the start of the
  parameter vector, which for these models holds the random effects, so the
  surface was computed from the wrong parameters. This was silent: a plausible
  but incorrect surface was returned rather than an error. Models without random
  effects, and all models fitted by `gvagpr()` and `gvagpmim()`, were unaffected.

* `computePPIPs()` and `summary()` work for a model with exactly two exposures,
  or two index groups. The sequential two-means step asks `kmeans()` for two
  clusters from two points, which the default Hartigan-Wong algorithm rejects;
  that degenerate case now uses MacQueen. Larger problems take exactly the same
  code path as before and their results are unchanged.

* `predict()` on an object of class `"gpmim"` accepts a matrix `Z_new`, where
  the number of rows was read from an intermediate list.

* `fitted()` no longer fails for `lengthscale = "normal"` with more than one
  exposure, where a vector of posterior medians was indexed as a matrix.

* `fitted()` on an object of class `"gpmim"` returns the posterior covariance
  matrix rather than its first element.

## Performance

* The convergence check now stops the algorithm regardless of `verbose`. In
  `gvagpr()` and `gvagpmim()` the test on the evidence lower bound was combined
  with the printing flag, so a fit with `verbose = FALSE` always ran for
  `control$max_iter` iterations. The returned estimates are those of the best
  recorded lower bound and are unchanged; only the running time is affected, and
  it can fall by more than an order of magnitude.

* Mixed effect models are substantially faster for large numbers of clusters.
  The triangular systems involving the Cholesky factor were solved with the
  LAPACK backend of `spsolve()`, which converts the factor to a dense matrix and
  runs a general LU factorization, giving a cost cubic in the number of
  parameters. They are now solved by substitution. Fitted values are unchanged.

## Other changes

* `fitted()` gains a `cov` argument. The posterior covariance matrix of the
  nonparametric part is `n` by `n` and can dominate the memory used by the call;
  `cov = FALSE` returns the fitted means only, and for the models fitted by
  `gvaggpr()` the dense kernel matrix is then never formed.

* A progress message computed `max_iter / 5` without guarding against zero.

## Documentation

* The `covstr` argument of `gvaggpr()` was documented as `"full"` in two places;
  the value accepted is `"fullrank"`.

* The `lengthscale` element of `priors` is now documented for all fitting
  functions.
