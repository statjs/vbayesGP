## Gaussian process logistic regression with the beta-prime prior on the
## length-scales, fitted by Polya-Gamma augmentation with inducing points.
## One of four exposures carries the surface.
set.seed(111)
n <- 1000
M <- 4
Z <- matrix(runif(n * M, -1, 1), n, M, dimnames = list(NULL, paste0("z", 1:M)))
X <- cbind(x = 3 * cos(Z[, 1]) + 2 * rnorm(n))
beta.true <- 0.1
h <- (2 * Z[, 1] + 0.5)^2
h <- h - mean(h)
y <- rbinom(n, 1, plogis(X %*% beta.true + h))

priors <- list(lengthscale = "betaprime", alam = 10, blam = 1, lam0 = 0.1, tau0 = 0.1)

## mini-batches of 200 observations (the default for a sample this size)
vbtime <- system.time(
  fit <- gvaggpr(y, X, Z, family = binomial(), priors = priors, covstr = "fullrank",
                 control = list(ninpts = 50, batch.size = 200), minibatch = TRUE,
                 verbose = FALSE, seed = 1)
)[3]
vbtime
plot(fit)
summary(fit)

## the surface against the truth, and the in-sample classification rate
hhat <- fitted(fit, cov = FALSE)$fmean
plot(h ~ hhat, pch = 20, xlab = "fitted surface", ylab = "true surface")
abline(a = 0, b = 1, col = "red", lwd = 2)
phat <- plogis(X %*% fit$mu[seq_len(ncol(X))] + hhat)
mean(y == as.integer(phat > 0.5))
