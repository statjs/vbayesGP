## Gaussian process multiple index model with a continuous outcome: three
## exposure groups enter through weighted indices.  The first index has eight
## exposures with decreasing weights, the second two exposures of opposite sign
## and no effect on the outcome, the third eight equal weights; the surface is
## additive in the first and third index scores with an interaction.
set.seed(0)
n <- 300
x1 <- matrix(runif(n * 8, -1, 1), n, 8); x2 <- matrix(runif(n * 2, -1, 1), n, 2)
x3 <- matrix(runif(n * 8, -1, 1), n, 8)
w1 <- 8:1;       w1 <- w1 / sqrt(sum(w1^2))
w2 <- c(-1, 1);  w2 <- w2 / sqrt(sum(w2^2))
w3 <- rep(-2, 8); w3 <- w3 / sqrt(sum(w3^2))
wx1 <- x1 %*% w1; wx2 <- x2 %*% w2; wx3 <- x3 %*% w3
h1fun <- function(z) dnorm(z - 0.2, 0, 0.5)
h3fun <- function(z) 1 / (1 + exp(-5 * z))
h <- as.numeric(h1fun(wx1) + h3fun(wx3) + 0.5 * h1fun(wx1) * h3fun(wx3))
covariates <- cbind(age = rnorm(n), sex = rbinom(n, 1, 0.5), bmi = rnorm(n))
gamma <- c(-0.43, -0.25, 0.12)
y <- as.numeric(h + covariates %*% gamma + rnorm(n, 0, 0.8))
Z <- list(metals = x1, phenols = x2, phthalates = x3)

## the horseshoe prior on the index coordinates, which gives inclusion probabilities
priors <- list(lengthscale = "horseshoe")

## mean field, then the full-rank variational covariance, on the whole sample
(mvb.time <- system.time(
  fout.diag <- gvagpmim(y, covariates, Z, priors = priors, covstr = "diagonal",
                        minibatch = FALSE, verbose = FALSE, seed = 1))[3])
summary(fout.diag)
computePPIPs(fout.diag)
mvb.h <- fitted(fout.diag, cov = FALSE)$fmean
coef(lm(h ~ mvb.h))                       # slope near one: the surface is recovered to scale

(fvb.time <- system.time(
  fout.full <- gvagpmim(y, covariates, Z, priors = priors, covstr = "fullrank",
                        minibatch = FALSE, verbose = FALSE, seed = 1))[3])
summary(fout.full)

## the same two fits on mini-batches (the default), which cap the cost per update
(mvbmb.time <- system.time(
  foutmb.diag <- gvagpmim(y, covariates, Z, priors = priors, covstr = "diagonal",
                          minibatch = TRUE, verbose = FALSE, seed = 1))[3])
summary(foutmb.diag)
cor(fitted(foutmb.diag, cov = FALSE)$fmean, h)
