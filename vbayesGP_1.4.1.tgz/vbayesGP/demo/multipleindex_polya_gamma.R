## The multiple index model with a binary and with a count outcome, and with a
## random intercept per cluster.  Six exposures in three indices; only the
## first two indices carry signal, and within the first only As and Cd do.
set.seed(1)
n  <- 300
g1 <- matrix(runif(n * 3, -1, 1), n, 3)
g2 <- matrix(runif(n * 2, -1, 1), n, 2)
g3 <- matrix(runif(n * 1, -1, 1), n, 1)
Z  <- cbind(As = g1[, 1], Cd = g1[, 2], Pb = g1[, 3],
            p1 = g2[, 1], p2 = g2[, 2], s1 = g3[, 1])
X  <- cbind(x1 = rnorm(n))
m.index <- list(metals = 1:3, phenols = 4:5, single = 6)
h   <- (2 * as.numeric(g1 %*% c(0.8, 0.6, 0)) + 0.5)^2 -
       (2 * as.numeric(g2 %*% c(0.7, 0.7)))^2
h   <- h - mean(h)
eta <- 0.3 * X[, 1] + h

## binary outcome, whole sample (a binary index model batches only from n = 500)
yb <- rbinom(n, 1, plogis(eta))
fb <- gvaggpmim(yb, X, Z, m.index, family = binomial(), control = list(ninpts = 30), minibatch = FALSE,
                verbose = FALSE, seed = 1)
summary(fb)                 # alpha.: index weights; gamma.: index length-scales
computePPIPs(fb)            # As, Cd, p1, p2 in; Pb, s1 and the third index out
plot(h ~ fitted(fb, cov = FALSE)$fmean, pch = 20, xlab = "fitted", ylab = "true")
abline(0, 1, col = "red")

## count outcome, with the dispersion estimated
yc <- rnbinom(n, size = 2, mu = exp(1 + 0.35 * eta))
fc <- gvaggpmim(yc, X, Z, m.index, family = negbinomial(), control = list(ninpts = 30), minibatch = FALSE,
                verbose = FALSE, seed = 1)
summary(fc)                 # 'theta' is the dispersion, true value 2
fc$c.unconverged            # routinely near one on counts; a report, not a warning

## a random intercept per cluster (blockdiag; "sparseprec" scales to many clusters)
nID <- 30
id  <- rep(seq_len(nID), each = n / nID)
b0  <- rnorm(nID, 0, 0.6)
yr  <- rbinom(n, 1, plogis(eta + b0[id]))
fr  <- gvaggpmim(yr, X, Z, m.index, id = id, family = binomial(), control = list(ninpts = 30),
                 covstr = "blockdiag", verbose = FALSE, seed = 1)
summary(fr)
re <- extractRandomEffects(fr)
re$Sigma.b                  # true variance 0.36
cor(re$mean[, 1], b0)
