## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>", fig.width = 6, fig.height = 4)

## ----library------------------------------------------------------------------
library(vbayesGP)

## ----data---------------------------------------------------------------------
set.seed(2026)
n <- 200
Z <- matrix(runif(n * 4, -1, 1), n, 4, dimnames = list(NULL, c("As", "Cd", "Pb", "Hg")))
X <- cbind(age = rnorm(n))
h <- 2 * Z[, "As"]^2 - 1.5 * Z[, "Cd"]^2 + Z[, "As"] * Z[, "Cd"]
h <- h - mean(h)
y <- 0.5 * X[, "age"] + h + rnorm(n, sd = 0.5)

## ----gauss--------------------------------------------------------------------
fit <- gvagpr(y, X, Z, minibatch = FALSE, verbose = FALSE, seed = 1)
fit

## ----gauss-summary------------------------------------------------------------
summary(fit)

## ----gauss-elbo---------------------------------------------------------------
plot(fit)
extractELBO(fit, nsamples = 500)

## ----gauss-fitted-------------------------------------------------------------
fm <- fitted(fit, cov = FALSE)$fmean
cor(fm, h)
coef(lm(h ~ fm))
pr <- predict(fit, Z_new = Z[1:3, ], cov = FALSE)
pr$fmean

## ----gauss-response-----------------------------------------------------------
univ <- predictorResponseUnivar(fit, ngrid = 25, nsamples = 300)
plot(univ)
risk <- computeOverallRisk(fit, qs = seq(0.25, 0.75, by = 0.05), nsamples = 300)
plot(risk)
sv <- computeSingVarRisk(fit, which.z = 1:4, nsamples = 300)
sv$summary

## ----gauss-bivar, fig.height = 5----------------------------------------------
biv <- predictorResponseBivar(fit, z.pairs = data.frame(z1 = 1, z2 = 2), ngrid = 15, nsamples = 300,
                              verbose = FALSE)
lev <- predictorResponseBivarLevels(biv, Z = Z, qs = c(0.1, 0.5, 0.9))
plot(lev)

## ----gauss-ppip---------------------------------------------------------------
fit.hs <- gvagpr(y, X, Z, priors = list(lengthscale = "horseshoe"),
                 minibatch = FALSE, verbose = FALSE, seed = 1)
computePPIPs(fit.hs, nsamples = 500)

## ----pg-----------------------------------------------------------------------
yb <- rbinom(n, 1, plogis(0.5 * X[, "age"] + h))
fitb <- gvaggpr(yb, X, Z, family = binomial(), priors = list(lengthscale = "betaprime"),
                control = list(ninpts = 30), minibatch = FALSE, verbose = FALSE, seed = 1)
summary(fitb)
yc <- rnbinom(n, size = 2, mu = exp(1 + 0.3 * X[, "age"] + 0.4 * h))
fitc <- gvaggpr(yc, X, Z, family = negbinomial(), control = list(ninpts = 30),
                minibatch = FALSE, verbose = FALSE, seed = 1)
summary(fitc)

## ----pg-tools-----------------------------------------------------------------
cor(fitted(fitb, cov = FALSE)$fmean, h)
computePPIPs(fitb, nsamples = 500)

## ----pg-cunc------------------------------------------------------------------
fitc$c.unconverged

## ----re-----------------------------------------------------------------------
nID <- 20
id <- rep(seq_len(nID), each = n / nID)
b0 <- rnorm(nID, 0, 0.6)
yr <- rbinom(n, 1, plogis(0.5 * X[, "age"] + h + b0[id]))
## the caps on the optimiser keep the document quick (see the index section)
ctl <- list(ninpts = 30, max_iter = 4000, nws = 500, nsp = 30)
fitr <- gvaggpr(yr, X, Z, id = id, family = binomial(), covstr = "blockdiag",
                control = ctl, verbose = FALSE, seed = 1)
summary(fitr)
re <- extractRandomEffects(fitr)
re$Sigma.b
cor(re$mean[, 1], b0)

## ----mim-data-----------------------------------------------------------------
set.seed(7)
g1 <- matrix(runif(n * 3, -1, 1), n, 3, dimnames = list(NULL, c("As", "Cd", "Pb")))
g2 <- matrix(runif(n * 2, -1, 1), n, 2, dimnames = list(NULL, c("p1", "p2")))
g3 <- matrix(runif(n * 1, -1, 1), n, 1, dimnames = list(NULL, "s1"))
Zm <- list(metals = g1, phenols = g2, single = g3)
s1 <- as.numeric(g1 %*% c(0.8, 0.6, 0))        # Pb carries no weight
s2 <- as.numeric(g2 %*% c(0.7, 0.7))           # the third index carries nothing
hm <- (2 * s1 + 0.5)^2 - (2 * s2)^2
hm <- hm - mean(hm)
ym <- 0.5 * X[, "age"] + hm + rnorm(n, sd = 0.5)
fitm <- gvagpmim(ym, X, Zm, priors = list(lengthscale = "horseshoe"),
                 minibatch = FALSE, verbose = FALSE, seed = 1)
summary(fitm)

## ----mim-ppip-----------------------------------------------------------------
computePPIPs(fitm, nsamples = 500)

## ----mim-pg-------------------------------------------------------------------
ymb <- rbinom(n, 1, plogis(0.5 * X[, "age"] + 0.7 * hm))
fitmb <- gvaggpmim(ymb, X, Zm, family = binomial(), control = ctl,
                   minibatch = FALSE, verbose = FALSE, seed = 1)
summary(fitmb)
cor(fitted(fitmb, cov = FALSE)$fmean, hm)

## ----mim-re-------------------------------------------------------------------
ymr <- rnbinom(n, size = 2, mu = exp(1.5 + 0.4 * X[, "age"] + 0.4 * hm + b0[id]))
fitmr <- gvaggpmim(ymr, X, Zm, id = id, family = negbinomial(), covstr = "blockdiag",
                   control = c(ctl[c("ninpts", "nws", "nsp")], max_iter = 8000),
                   verbose = FALSE, seed = 1)
summary(fitmr)
extractRandomEffects(fitmr)$Sigma.b

## ----session------------------------------------------------------------------
sessionInfo()

